/* Dummy file provided to be a special dependency of version.cxx
   to ensure that the correct build timestamp is compiled 
   in the gatekeeper executable
*/
